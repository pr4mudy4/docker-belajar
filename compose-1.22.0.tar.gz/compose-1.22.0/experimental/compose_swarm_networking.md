# Experimental: Compose, Swarm and Multi-Host Networking

Compose now supports multi-host networking as standard. Read more here:

https://docs.docker.com/compose/networking
